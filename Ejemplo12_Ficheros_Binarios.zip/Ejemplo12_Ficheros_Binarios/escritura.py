import pickle

# Abrir el fichero en modo escritura y binario
fichero = open("Ejemplo12_Ficheros_Binarios/fichero.pckl", "wb")

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}

# Escribir el conjunto frutas en el fichero
pickle.dump(frutas, fichero)

# Cerrar el fichero
fichero.close()