# pip install mysql-connector-python
import mysql.connector

# Abrir la conexion
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="indra"
)

# Obtener un cursor
cursor = conexion.cursor()

''' ************************ Insert *********************** '''
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

lista = [(3, 'Teclado', 29.95), (4, 'Raton', 18.90), (5, 'Impresora', 89.25), (6, 'Auriculares', 230)]
sql = "insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (%s,%s,%s)"
#cursor.executemany(sql, lista)
#conexion.commit()

''' ************************ Consultas *********************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall() # recoger los resultados de la query
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos con precio inferior a 50
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos cuya descripcion sea Impresora
parametro = ('Impresora',) # Los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion = %s", parametro)
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos ordenados por precio ascendente
cursor.execute("select * from PRODUCTOS ORDER by precio")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos ordenados por precio descendente
cursor.execute("select * from PRODUCTOS ORDER by precio DESC")
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos que comiencen por la letra R
parametro = ('R%',) # Los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s", parametro)
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos  que contienen la letra e y el precio es inferior a 50
parametros = ('%e%', 50) # Los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s and precio < %s", parametros)
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("---- FIN ----")

''' ************************ Modificar datos *********************** '''
# subir un 10% el precio de la Impresora
parametros = ('Impresora',) # Los parametros se pasan en tuplas
cursor.execute("update PRODUCTOS set precio = precio * 1.1 where descripcion = %s", parametros)
conexion.commit()

''' ************************ Eliminar *********************** '''
# Eliminar todos los ratones
parametros = ('Raton',) # Los parametros se pasan en tuplas
cursor.execute("delete from PRODUCTOS where descripcion = %s", parametros)
conexion.commit()

# Cerrar la conexion
conexion.close()