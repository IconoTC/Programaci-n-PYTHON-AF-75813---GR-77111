'''
    solicitar un numero entre 1 y 10
    mostrar un mensaje si es menor que 1 o mayor que 10
'''

numero = int(input("Introduce numero (1-10): "))

# Version 1
if numero < 1:
    print("No puede ser menor que 1")
else:
    if numero > 10:
        print("No puede ser mayor que 10")
    else:
        print("El numero es correcto")
        
# Version 2
if numero < 1:
    print("No puede ser menor que 1")
elif numero > 10:
    print("No puede ser mayor que 10")
else:
    print("El numero es correcto")   
    
# Version 3
if numero < 1: print("No puede ser menor que 1")
elif numero > 10: print("No puede ser mayor que 10")
else: print("El numero es correcto")     