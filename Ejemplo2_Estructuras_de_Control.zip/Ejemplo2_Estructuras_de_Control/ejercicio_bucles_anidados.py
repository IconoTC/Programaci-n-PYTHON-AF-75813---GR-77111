'''
    Mostrar las tablas de multiplicar del 1 al 10
'''

for tabla in range(1,11):
    print("***** Tabla del", tabla, "*****")
    
    for num in range(1,11):
        print(tabla, "x", num, "=", tabla*num)
    print()