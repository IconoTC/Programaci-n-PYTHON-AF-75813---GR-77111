# Los lambdas son funciones anonimas
# se recomienda su uso cuando el cuerpo de la funcion es una sola linea
# Sintaxis: lambda parametros: cuerpo de la funcion

''' ************* map *************  '''
# Ejemplo 1
numeros = [3,8,5,14,28]
numeros_dobles = list(map(lambda numero: numero * 2, numeros))
print(numeros) # la coleccion original no se modifica
print(numeros_dobles)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
nuevas_notas = dict(map(lambda item: (item[0], item[1]+1), alumnos.items()))
print(nuevas_notas)

# Ejemplo 3
class Persona:
    def __init__(self, nombre: str, edad: int) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)

personas = [Persona("Juan",27), Persona("Maria",15), Persona("Pedro",21)]
personas = list(map(lambda persona: Persona(persona.nombre.upper(), persona.edad + 1), personas))
print(personas)
for p in personas:
    print(p)
    
''' ************* filter *************  '''
# Ejemplo 1
numeros = [3,8,5,14,28]
numeros_pares = list(filter(lambda numero: numero % 2 == 0, numeros))
print(numeros_pares)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)
alumnos_suspensos = dict(filter(lambda item: item[1] < 5, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
personas = [Persona("Juan",27), Persona("Maria",15), Persona("Pedro",21)]
personas_menores = list(filter(lambda persona: persona.edad < 18, personas))
for p in personas_menores:
    print(p)
    
''' ************* reduce *************  '''

''' Para utilizar reduce hay que importarlo '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,5,14,28]
print("Suma:", reduce(lambda acumulado, num: acumulado + num, numeros))


# Ejemplo
nombres = ['Juan', 'Maria', 'Pedro', 'Luis']
print(reduce(lambda acumulado, nombre: acumulado.upper() + " - " + nombre.upper(), nombres))