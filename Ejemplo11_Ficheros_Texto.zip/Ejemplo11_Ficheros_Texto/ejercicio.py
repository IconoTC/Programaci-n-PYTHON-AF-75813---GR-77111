''' 
    leer la informacion fichero.txt y generar una copia copia.txt (w+t)
    mostrar el contenido de copia.txt
'''

# Abrir el fichero en modo lectura
fichero_lectura = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero en modo lectura y escritura
fichero_copia = open("Ejemplo11_Ficheros_Texto/copia.txt", "w+t", encoding="utf-8")

# leer el contenido del fichero en una lista
contenido = fichero_lectura.readlines()

# escribir el contenido en el fichero copia.txt
for linea in contenido:
    fichero_copia.write(linea)
    
# leer copia.txt
fichero_copia.seek(0)
for linea in fichero_copia.readlines():
    print(linea, end="")

# cerrar ambos ficheros
fichero_lectura.close()
fichero_copia.close()