# Abrir el fichero en modo escritura
fichero = open("Ejemplo11_Ficheros_Texto/fichero.txt", "wt", encoding="utf-8")

# Agregar texto
texto = ""
while texto != "FIN":
    texto = input("Introduce texto, (FIN) para terminar: ") 
    if texto == "FIN":
        break
    fichero.write(texto)
    fichero.write("\n")
    
# cerrar el fichero
fichero.close()