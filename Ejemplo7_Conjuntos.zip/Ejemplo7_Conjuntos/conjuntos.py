# conjuntos: colecciones sin orden, no tenemos indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Se crean: {}
# IMPORTANTE: conjunto = {} lo interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas)) # <class 'set'>
print(frutas)

# Conjunto vacio
conjunto = set()
print(type(conjunto)) # <class 'set'>
conjunto = {}
print(type(conjunto)) # <class 'dict'>

# agregar elementos al conjunto
frutas.add("fresas")
print(frutas)

# eliminar un elemento
frutas.remove("platano")
print(frutas)

# Para recorrer conjuntos for in
for item in frutas:
    print(item, end=" ")
print()

# Copiar un conjunto en otro
otro = frutas.copy()

# Operadores de pertenencia
print("manzana" in frutas) # True
print("manzana" not in frutas) # False

# Borrar todos los elementos
frutas.clear()
print(frutas)