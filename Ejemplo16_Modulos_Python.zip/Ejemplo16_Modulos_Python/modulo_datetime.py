# Este modulo continen funciones para manejar fechas y horas

import datetime
import time

hoy = datetime.date(2025,3,7)
print(hoy)

print(hoy.year)
print(hoy.month)
print(hoy.day)

# Formato personalizado
dt = datetime.datetime(2025,3,7,10,39,55,30)
print(dt.date().strftime('%d/%m/%y'))
print(hoy.strftime('%d/%m/%y'))
print(dt.time().strftime('%H:%M:%S'))

# A que dia de la semana corresponde empezando 0=lunes
print("Dia semana:", hoy.weekday())

# A que dia de la semana corresponde empezando 1=lunes
print("Dia semana:", hoy.isoweekday())

# Fecha de mañana
print("Mañana", hoy.replace(day=8))

# Fecha y hora actual
print("Ahora:", datetime.datetime.now())

# Crear un periodo de tiempo
periodo = datetime.timedelta(days=7, hours=6)
print(datetime.datetime.today() + periodo)

# Desde el modulo time podemos obtener la hora actual
print(time.ctime())