# Este modulo contiene funciones para trabajar con el sistema operativo

import os

# Fecha y hora actual del sistema
print(os.system('date')) # Fri Mar  7 09:31:20 CET 2025

# borrar carpeta o direcorio
os.rmdir('Ejemplo16_Modulos_Python/mi_carpeta')

# crear una carpeta o directorio
os.mkdir('Ejemplo16_Modulos_Python/mi_carpeta')

# En que directorio estoy?
print("Estoy en:", os.getcwd())

# Mover a mi_carpeta
os.chdir('Ejemplo16_Modulos_Python/mi_carpeta')

# En que directorio estoy?
print("Estoy en:", os.getcwd())

# Para poder ejecutar comandos del so
os.system('mkdir otra_carpeta')
os.system('mkdir otra_mas')

# Mostrar los directorio dentro de mi_carpeta
print(os.listdir())

