# Este modulo contiene funciones para manejar calendarios

import calendar
import locale

# mostrar el calendario 2025
print(calendar.calendar(2025,c=10, m=4)) 

# mostrar el calendario de marzo 2025
print(calendar.month(2025, 3)) 

# Calendario que comience en domingo 
calendar.setfirstweekday(6)
print(calendar.month(2025, 3)) 

# Los dias de la semana
print(calendar.weekheader(1))
print(calendar.weekheader(2))
print(calendar.weekheader(3))

# Saber si un año es bisiesto
print("2024 es bisiesto", calendar.isleap(2024)) # True
print("2025 es bisiesto", calendar.isleap(2025)) # False

# A partir del modulo locale podemos obtener el calendario en español
l = locale.setlocale(locale.LC_ALL, "es_ES")
c = calendar.LocaleTextCalendar(locale=l)
print(c.formatmonth(2025, 3))