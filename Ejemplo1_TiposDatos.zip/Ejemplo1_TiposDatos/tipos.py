'''
    Comentarios de bloque
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 8
numero2 = 4
suma = numero1 + numero2
# TypeError: can only concatenate str (not "int") to str
# print("Suma: " + suma)
print("Suma: " + str(suma))
print("Suma:", suma, ", Tipo:", type(suma))

# numeros reales (float)
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print("Area del triangulo:", triangulo, ", Tipo:", type(triangulo))
print("Area del triangulo:", round(triangulo, 2), ", Tipo:", type(triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, ", Tipo:", type(soltero))

# Cadenas de texto (str)
# se puede utilizar comillas dobles o simples
nombre = "Juan"
apellido = 'Lopez'
print(nombre, apellido, ", Tipo:", type(nombre))
