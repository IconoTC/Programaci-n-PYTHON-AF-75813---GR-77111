import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato)) # str
numero1 = int(dato)
print(type(numero1)) # int
numero2 = int(input("Introduce otro numero: "))
print("Suma:", numero1+numero2)
# int("9.56") ValueError: invalid literal for int() with base 10: '9.56'

# convertir de texto a numero real
radio = float(input("Introduce radio del circulo: "))
print("Area del circulo", math.pi * math.pow(radio, 2))
print("Area del circulo", math.pi * radio ** 2)
# ValueError: could not convert string to float: '5,3455'
# Si introduzco el radio como valor entero funciona sin problemas

# convertir numero a booleano
soltero = 0 # es el unico caso que lo convirte a False, todo lo demas es True
print("Estas soltero:", bool(soltero))

# convertir a texto
texto = str(radio)
print("Radio: " + texto)