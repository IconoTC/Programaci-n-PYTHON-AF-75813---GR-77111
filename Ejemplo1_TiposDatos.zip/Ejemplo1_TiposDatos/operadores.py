# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 5
print("Division:", numero1 / numero2) # 1.4
print("Division entera:", numero1 // numero2) # 1
print("Resto de la division:", numero1 % numero2) # 2

# Operadores de asignacion (+=, -=, *=, /=, %=, **=, //=)
numero1 += 5  # numero1 = numero1 + 5

# En Python no existen incrementos y decrementos
numero1 += 1  # numero1++   
numero1 -= 1  # numero1--

# Operadores de comparacion (<,>,<=,>=,==,!=)
print("numero1 es menor que numero2", numero1 < numero2)  # False
print("numero1 es igual a 5", numero1 == 5) # True
print("numero1 es distinto de 5", numero1 != 5) # False

# Operadores logicos (and, or, not)
print("and:", (numero2 > 1 and numero2 == 5)) # True porque ambas condiciones son ciertas
print("and:", (numero2 > 10 and numero2 == 5)) # False la primera condicion es False
print("or:", (numero2 > 10 or numero2 == 5)) # True
print("not:", not(numero2 > 10)) # True
print("not:", not(numero2 == 12345)) # True
print("not:", not(numero2 == 5)) # False
print("not:", not(numero2 > 1 and numero2 == 5)) # False

# Operadores de identidad (is, is not)
# Sirven para verificar si es el mismo objeto
num1 = 6
num2 = 6
print("Es el mismo objeto", num1 is num2) # True

nombres1 = ["Juan", "Maria"]
nombres2 = ["Juan", "Maria"]
print("Es el mismo objeto", nombres1 is nombres2) # False porque las direcciones de memoria son distintas
print("No es el mismo objeto", nombres1 is not nombres2) # True

# Operadores de pertenencia (in, not in)
print("Luis esta en nombres1:", "Luis" in nombres1) # False
print("Luis no esta en nombres1:", "Luis" not in nombres1) # True
print("Maria esta en nombres1:", "Maria" in nombres1) # True