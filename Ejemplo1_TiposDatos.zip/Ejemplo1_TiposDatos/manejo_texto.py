texto = "bienvenidos al curso de Python"

print(texto.capitalize()) # solo la primera letra de la frase en mayuscula
print(texto.title()) # En mayuscula la primera letra de cada palabra
print(texto.upper()) # Todo en mayusculas
print(texto.lower()) # Todo en minusculas
print(texto.swapcase()) # Intercambiamos mayusculas por minusculas

print("isalnum", texto.isalnum()) # (solo letras y numeros) False por los espacios en blanco
print("isalnum", "texto".isalnum()) # True
print("isalnum", "123456".isalnum()) # True
print("isalnum", "texto1234".isalnum()) # True

print("isalpha", texto.isalpha()) # (solo letras) False por los espacios en blanco
print("isalpha", "texto".isalpha()) # True
print("isalpha", "texto1234".isalpha()) # False

print("isdigit", texto.isdigit()) # (solo numeros) False por letras y espacios en blanco
print("isdigit", "12345".isdigit()) # True
print("isdigit", "12 345".isdigit()) # False
# isdecimal() la diferencia con isdigit() es que isdecimal() tambien soporta UNICODE

print("isupper", texto.isupper()) # (solo mayusculas, ignora si hay numeros,espacios u otro caracter)  False
print("isupper", "HOLA".isupper()) # True
print("isupper", "HOLA1234".isupper()) # True
print("isupper", "HOLA 1234".isupper()) # True
print("isupper", "HOLA_1234".isupper())

print("islower", texto.islower()) # (igual pero con minusculas) # False
print("islower", "hola".islower()) # True
print("islower", "hola1234".islower()) # True

print("Longitud:", len(texto)) # Numero de caracteres de la cadena de texto
print("Longitud:", texto.__len__()) # Es privado pero se puede acceder y FUNCIONA

# La tabla ASCII esta ordenada de esta forma (1ºnumeros, 2ºmayusculas, 3ºminusculas)
print("max", max(texto)) # El caracter con mas valor en la tabla ASCII
print("min", min(texto)) # El caracter con menos valor en la tabla ASCII es el espacio en blanco " "
print("max", max("1Pm")) # m
print("min", min("1Pm")) # 1

ejemplo = "    Hoy es lunes    "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n") # Elimina espacios por la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n") # Elimina espacios por la derecha
print("strip", ejemplo.strip(), end=".\n") # Elimina espacios por la izquierda y derecha

print("replace", texto.replace("e", "E")) # Reemplaza todas las letras e
print("replace", texto.replace("e", "E", 1)) # Solo reemplaza la primera letra e que encuentra

palabras = texto.split() # Por defecto parte la cadena por el espacio en blanco
print(type(palabras)) # el resultado es una lista <class 'list'>

# Los indices empiezan desde 0
print("find", texto.find("o"))  # 9  Devuelve la primera posicion por la izquierda donde se encuentra la a
print("find", texto.find("o", 10)) # 19 Empieza a buscar a partir de 10
print("find", texto.find("o", 10, 15)) # -1 Busca entre la posicion 10 y 14 (el 15 no entra)
print("rfind", texto.rfind("o")) # 28 Devuelve la primera posicion por la derecha
print("find", texto.find("-")) # -1 si no existe ese caracter
