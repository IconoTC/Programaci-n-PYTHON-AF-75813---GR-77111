# try-except-else-finally

import traceback

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ValueError as ex:
    print("El valor introducido no es numerico")
    print(ex)
except ZeroDivisionError as error:
    print("No se puede dividir por cero")
    # Mostrar la pila de llamadas (stack trace)
    traceback.print_exc()
except Exception as e:
    print("Ha ocurrido un error")
    print(e)
else:
    # se ejecuta cuando no hay ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya error o no   
    print("******** FIN *******")
    
    
''' Estructuras minimas '''
try:
    pass
finally:
    pass

try:
    pass
except:
    pass

''' Esto no compila 
try:
    pass
else:
    pass
'''