# Las aserciones son afirmaciones que en base a una condicion:
#   - True: no pasa nada
#   - False: genera AssertionError
# La ventaja de utilizar aserciones en vez de condicionales (if-else)
# es que, una vez el codigo testeado antes de ir a produccion las
# aserciones se pueden deshabilitar con el siguiente comando:
#   python -O codigo.py
# otra forma seria:
#   set PYTHONOPTIMIZE=1  variable de entorno que deshabilita las aserciones
#   python codigo.py

edad = int(input("Introduce tu edad: "))
assert edad >= 18, "No eres mayor de edad"

# Probamos desde linea de comandos a deshabilitar las aserciones
# python3 -O /Users/anaisabelvegascaceres/Desktop/Python_Indra_3_Marzo_2025/Ejemplo10_Excepciones/aserciones.py