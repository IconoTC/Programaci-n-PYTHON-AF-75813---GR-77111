# 1ª forma: importar el modulo completo
import persona

luis = persona.Persona("Luis", 50)    # modulo.recurso
print(luis)

# 2ª forma: importar el recurso de un modulo
from persona import Persona

marta = Persona("Marta", 34)   # recurso
print(marta)

# 3ª forma: importar el recurso del modulo con un alias
from persona import Persona as Per 

jorge = Per("Jorge", 24)   # alias
print(jorge)