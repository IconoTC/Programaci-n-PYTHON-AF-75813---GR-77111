# Funcion con un numero variable de argumentos
def sumar(*numeros): # numeros es una tupla
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(9))
print(sumar(9,2))
print(sumar(9,2,5))
print(sumar(9,2,5,7))

'''
    crear una funcion que recibe el nombre y las notas del alumno
    utilizando la funcion sumar() calcular la nota media
    devolver el nombre en mayusculas y la nota media
'''
def procesarNotas(nombre, *notas):
    # sumar(notas) estoy enviando una tupla de datos
    # sumar(*notas) estoy enviando como numero variable de argumentos
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

# TypeError: unsupported operand type(s) for +=: 'int' and 'str'
# print(procesarNotas(2,5,3, "Juan")) esta intentando sumar el nombre
print(procesarNotas("Juan", 2,5,3))
print(procesarNotas("Maria", 9,8))
print(procesarNotas("Pedro", 7,5,9,6))   