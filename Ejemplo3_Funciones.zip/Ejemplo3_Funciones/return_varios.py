'''
    Crear una funcion que recibe un texto y retorne:
        - el texto en mayusculas
        - el texto en minusculas
        - la longitud del texto
'''

def procesarTexto(texto):
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud

# recuperar con multiples variables
txtMay, txtMin, txtLen = procesarTexto("Buenos dias")
print(txtMay)
print(txtMin)
print(txtLen)

# recuperar con una coleccion de tipo tupla
tupla = procesarTexto("Buenos dias")
for dato in tupla:
    print(dato)