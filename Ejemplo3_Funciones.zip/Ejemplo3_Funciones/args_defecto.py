# Crear una funcion con argumento por defecto
def datosTrabajador(nombre: str, estadoCivil="Soltero", sueldo=24000):
    print(nombre, "esta", estadoCivil, "gana", sueldo)
    
datosTrabajador("Juan")
# interpreta que 37000 es el estadoCivil
datosTrabajador("Maria", 37000)
datosTrabajador("Maria", sueldo=37000)

# TypeError: datosTrabajador() missing 1 required positional argument: 'nombre'
#datosTrabajador()  El nombre es obligatorio

# Puedo cambiar el orden pero hay que poner el nombre del argumento
datosTrabajador(sueldo=37000, nombre="Maria")

'''
    En Python se pueden pasar los argumentos de 2 formas:
        - por posicion: datosTrabajador("Juan")
        - keywords: datosTrabajador(sueldo=37000, nombre="Maria") 
'''

'''
    crear una funcion que reciba datos como numero variable de argumentos
    recibir un separador que por defecto sera " | "
    retornar el numero de datos recibidos y una cadena que una todos los datos con el separador (join)
'''
def concatenar(*datos, separador=" | "):
    return len(datos), separador.join(datos)

print(concatenar('a','e','i','o','u'))
print(concatenar('a','e','i','o','u', separador="-"))
print(concatenar('a','e','i','o','u', separador=", "))

# No funciona
# print(concatenar(separador="-", 'a','e','i','o','u' ))