# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de distinto tipo
# permite tener elementos duplicados
# se crean []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]
print(list1)
print(list2)

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas
lista = list1 + list2 # el orden es importante
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud:", len(lista))

# Acceso a los elementos de la lista
# indice positivo comienza por el primero, por la izquierda
print(lista[2])
# indice negativo comienza por el ultimo, por la derecha 
print(lista[-2])
print(lista[len(lista)-2]) # 8-2=6

# Agregar elementos al final -> append
lista.append("morena")
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez -> extend
lista.extend([1,2,3]) # los elementos tienen que ir en una coleccion iterable
print(lista)

# Eliminar elementos por posicion
del lista[0] # 0 es un indice
print(lista)

# Eliminar el primer elemento que encuentra
lista.remove(3)  # 3 es el valor que buscamos
print(lista)

# Buscar un elemento y me retorna el indice donde se encuentra
indice = lista.index("Perez")
print(indice)

# Mostrar cuantas soltera hay
print("Cuantas soltera?", lista.count("soltera"))

# Mostrar la lista y la lista invertida
print(lista)
lista.reverse()
print(lista)

# Ordenar listas
colores = ['rojo', 'verde', 'azul', 'amarillo']
print(sorted(colores))  # La muestra ordenada pero no la modifica
print(colores)
print(sorted(colores, reverse=True)) # Orden descendente

''' Ordenar por key '''
print(sorted(colores, key=lambda dato: len(dato) )) # ordenar la lista por la longitud de cada elemento

# Eliminar todos los elementos de la lista
colores.clear()
print(colores)

''' Operadores de pertenencia: in y not in '''
print("hola" in lista)
print("hola" not in lista)

''' slices [begin:stop:step] '''
# mostrar todos los elementos de la lista
print("Todos", lista[:])

# mostrar los ultimos 4 elementos de la lista
print("Ultimos 4", lista[-4:])

# mostrar los elementos desde el indice 3 al 6
print("Del 3 al 6", lista[3:7]) # el ultimo no esta incluido, como los rangos

# mostrar desde el indice 6 al 3
print("Del 6 al 3", lista[6:2]) # sale la lista vacia
print("Del 6 al 3", lista[6:2:-1])

# mostrar del penultimo al quinto
print("Del penultimo al quinto", lista[-2:4:-1])

# mostrar todos pero en orden inverso
print("Todos inverso", lista[::-1])

# mostrar todos en orden ascendente de 2 en 2
print("Todos ascendente de 2 en 2", lista[::2])

# mostrar todos en orden descendente de 2 en 2
print("Todos descendente de 2 en 2", lista[::-2])
