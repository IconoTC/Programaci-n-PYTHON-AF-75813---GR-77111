# crear una lista llamada colores con rojo, verde y azul
colores = ["rojo", "verde", "azul"]

# mostrar el tipo de la variable colores
print(type(colores))

# mostrar el contenido de la lista
print(colores)

# recorrer la lista con for in
for item in colores:
    print(item, end=" ")
print()

# recorrer la lista a traves de indice con range
for idx in range(len(colores)):
    print(colores[idx], end=" ")
print()

# mostrar el color verde por posicion
print(colores[1])

# Borrar el color azul por posicion (del)
#del colores[2]
#print(colores)

# Borrar el color azul, busco el primero y lo borro (remove)
colores.remove("azul")
print(colores)

# Crear una lista vacia mas_colores
mas_colores = []
mas_colores = list()

# en la nueva lista concatenar colores con otra lista con elementos: [blanco, negro, rosa y azul]
mas_colores = colores + ["blanco", "negro", "rosa", "azul"]

# añadir el color naranja al final
mas_colores.append("naranja")

# añadir el color marron al principio
mas_colores.insert(0, "marron")
print(mas_colores)

# mostrar la longitud de la lista
print("Longitud:", len(mas_colores))

''' slices '''
# mostrar los 2 ultimos elementos
print(mas_colores[-2:])

# mostrar desde el ultimo al antepenultimo
print(mas_colores[-1:-4:-1])

# mostrar los 5 primeros elementos
print(mas_colores[:5])

# mostrar del indice 2 al 4
print(mas_colores[2:5])

# mostrar del 0 al penultimo de 2 en 2
print(mas_colores[0:-1:2])

# mostrar desde el penultimo al primero de 2 en 2
print(mas_colores[-2::-2])