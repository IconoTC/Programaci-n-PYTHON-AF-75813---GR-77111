# listas de una dimension
lista = [1,2,3,4,5]  # un solo indice

# listas de 2 dimensiones
matriz = [ [2,7,4], [3,9,5], [8,1,6] ]  # 2 indices (fila, columna)

for fila in matriz:
    for item in fila:
        print(item, end=" ")
    print()
    
# matrices no cuadradas, cada fila tiene diferente numero de columnas
matriz2 = [ [2,7,4,1], [3,9,5,6,0], [8,1] ]

for fila in matriz2:
    for item in fila:
        print(item, end=" ")
    print()
    
for fila in range(len(matriz2)) :
    for col in range(len(matriz2[fila])):
        print(matriz2[fila][col], end=" ")
    print()