# Ejemplo 1
# crear una tupla con el cuadrado de cada numero
numeros = (1,2,3,4,5)
tupla_cuadrados = tuple(num**2 for num in numeros)
print(tupla_cuadrados)

# Ejemplo 2
# Crear una tupla con pares(dia,longitud) de los elementos de dias que comienzan por m
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
tupla_dias = tuple( (dia, len(dia)) for dia in dias if dia.startswith("m"))
print(tupla_dias)
