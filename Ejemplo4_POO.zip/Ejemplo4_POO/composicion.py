class Direccion:
    def __init__(self, calle:str, numero:int, poblacion:str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
    
    # sobreescribir el metodo heredado de la clase Object    
    def __str__(self) -> str:
        # Gran Via, 6 (Madrid)
        return "{}, {}, ({})".format(self.calle, self.numero, self.poblacion)

class Persona:
    def __init__(self, nombre:str, edad:int, direccion:Direccion) -> None:
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
        
    def mostrarInfo(self):
        print("Me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion))

dirJuan = Direccion("Gran Via", 6, "Madrid")
print(dirJuan) # si no sobreescribo __str__ muestra esto <__main__.Direccion object at 0x1092d6360>

p1 = Persona("Juan", 23, dirJuan)
p2 = Persona("Maria", 42, Direccion("Diagonal", 128, "Barcelona"))

p1.mostrarInfo()
p2.mostrarInfo()

# Los atributos o propiedades son publicas
p1.edad += 1
# Cambiar la direccion de Juan Castellana, 61, Madrid
p1.direccion.calle = "Castellana"
p1.direccion.numero = 61
p1.mostrarInfo()