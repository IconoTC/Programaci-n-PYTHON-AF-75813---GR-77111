'''
    Crear una clase Figura con propiedades: x,y
    funcion calcular_area (pass)
    funcion __str__ retorne [x,y]
    
    Crear las clases Circulo, Triangulo y Rectangulo
    necesitareis nuevos atributos o propiedades
    sobreescribir el metodo calcular_area
    
    crear instancias de cada figura y mostrar el area y __str__
'''

class Figura:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
        
    def calcular_area(self):
        pass
    
    def __str__(self) -> str:
        return f"[{self.x},{self.y}]"

import math
class Circulo(Figura):   
    def __init__(self, x, y, radio) -> None:
        super().__init__(x, y)
        self.radio = radio
        
    def calcular_area(self):
        return math.pi * math.pow(self.radio, 2)
    
    def __str__(self) -> str:
        return super().__str__() + f" Radio: {self.radio}"
    
class Triangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura / 2
    
    def __str__(self) -> str:
        return super().__str__() + f" Base: {self.base} Altura: {self.altura}"
    
class Rectangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura
    
    def __str__(self) -> str:
        return super().__str__() + f" Base: {self.base} Altura: {self.altura}"
    
circulo = Circulo(10,5, 4.56)
print(circulo)
print("Area del circulo:", circulo.calcular_area())

triangulo = Triangulo(10,5, 50,29)
print(triangulo)
print("Area del triangulo:", triangulo.calcular_area())

rectangulo = Rectangulo(10,5, 200,100)
print(rectangulo)
print("Area del rectangulo:", rectangulo.calcular_area())