class Persona:
    
    # constructor o inicializador
    def __init__(self, nombre, edad) -> None:
        #pass # significa que el cuerpo esta vacio
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self):
        #print("Me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))
        

# crear objetos o instancias de Persona
p1 = Persona("Juan", 23) # En p1 guardamos la direccion de memoria del objeto que acabamos de crear
p2 = Persona("Maria", 42)

# Invocar a los recursos del objeto
p1.mostrarInfo()

# Los atributos o propiedades son publicas
p1.edad += 1
p1.mostrarInfo()